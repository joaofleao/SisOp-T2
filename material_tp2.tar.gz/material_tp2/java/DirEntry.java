public class DirEntry {
	byte[] filename = new byte[25];
	byte attributes;
	short first_block;
	int size;
}
